public class RandomMutationHillClimbing
{
    private List<double> items; 
    private double binCapacity; 
    private Random random; 

    public RandomMutationHillClimbing(List<double> items, double binCapacity)
    {
        if (items == null || items.Count == 0)
            throw new ArgumentException("Item list cannot be null or empty.");
        if (binCapacity <= 0)
            throw new ArgumentException("Bin capacity must be greater than zero.");

        this.items = items;
        this.binCapacity = binCapacity;
        random = new Random();
    }

    public List<int> GenerateRandomInitialSolution()
    {
        var binAssignments = new List<int>(); 
        var bins = new List<List<double>>();  // Track bins content to measure overflow

        foreach (var item in items)
        {
            // Get a list of valid bins 
            List<int> validBins = new List<int>();

            for (int i = 0; i < bins.Count; i++)
            {
                if (bins[i].Sum() + item <= binCapacity)
                {
                    validBins.Add(i);
                }
            }

            validBins.Add(bins.Count);// Can create a new bin


            int selectedBinIndex = validBins[random.Next(validBins.Count)];// Randomly choose a valid bin

            if (selectedBinIndex == bins.Count)
            {
                // Create a new bin 
                bins.Add(new List<double> { item });
                binAssignments.Add(bins.Count); 
            }
            else
            {
                // Assign item to the selected existing bin
                bins[selectedBinIndex].Add(item);
                binAssignments.Add(selectedBinIndex + 1); 
            }
        }

        return binAssignments;
    }

    public double EvaluateFitness(List<int> solution)
    {
        return solution.Distinct().Count(); // the amount of different bins used
    }

    
    public List<int> SmallChange(List<int> solution)
    {
        var newSolution = new List<int>(solution);
        var bins = GetBins(newSolution);

        // Pick a random item
        int itemIndex = random.Next(newSolution.Count);
        double itemWeight = items[itemIndex];
        int currentBinIndex = newSolution[itemIndex] - 1;

        // Try to find a valid new bin
        int newBinIndex = random.Next(bins.Count + 1); // Allow adding a new bin as an option (despite going against the fitness)
        while (newBinIndex == currentBinIndex ||
               (newBinIndex < bins.Count && bins[newBinIndex].Sum() + itemWeight > binCapacity))
        {
            newBinIndex = random.Next(bins.Count + 1);
        }

        // Move the item to the new bin created
        if (newBinIndex >= bins.Count)
        {
            bins.Add(new List<double> { itemWeight }); 
        }
        else
        {
            bins[newBinIndex].Add(itemWeight);
        }
        bins[currentBinIndex].Remove(itemWeight);

        // Update solution to reflect the new bin assignments
        for (int i = 0; i < items.Count; i++)
        {
            for (int j = 0; j < bins.Count; j++)
            {
                if (bins[j].Contains(items[i]))
                {
                    newSolution[i] = j + 1;
                    break;
                }
            }
        }

        return newSolution;
    }

    // Execute the Random Mutation Hill Climbing algorithm
    public void RunRMHC(int iterations)
    {
        if (iterations <= 0)
            throw new ArgumentException("Number of iterations must be greater than zero.");

        // Generate an initial solution
        var bestSolution = GenerateRandomInitialSolution();
        double bestFitness = EvaluateFitness(bestSolution);

        Console.WriteLine("Initial Solution:");
        PrintSolution(bestSolution);

        ReadWriteFile.writeSolutions(new List<List<int>> { bestSolution },"C:\\Users\\lewis\\Downloads\\Coding\\2024\\BinPackingProblem\\solutions.csv");

        // Iterate and attempt to improve the solution
        for (var i = 0; i < iterations; i++)
        {
            Console.WriteLine($"Iteration {i + 1}: Current Best Fitness: {bestFitness}");

            var newSolution = SmallChange(bestSolution);
            var newFitness = EvaluateFitness(newSolution);

            PrintSolution(newSolution);
            Console.WriteLine($"New Fitness: {newFitness}");

            if (newFitness < bestFitness)
            {
                bestSolution = newSolution;
                bestFitness = newFitness;
                Console.WriteLine("Accepted new solution.");
            }
            else
            {
                Console.WriteLine("Rejected new solution.");
            }
            Console.WriteLine();
        }

        Console.WriteLine("Final Solution:");
        Console.WriteLine($"Bins Used: {bestFitness}");
        PrintSolution(bestSolution);
    }

    // Print a solution with bin assignments
    private void PrintSolution(List<int> solution)
    {
        Console.WriteLine("Bin Assignments for Items:");
        Console.WriteLine(string.Join(", ", solution)); // Print bin indices
    }

    //reconstructs bins from solution
    private List<List<double>> GetBins(List<int> solution)
    {
        var bins = new List<List<double>>();

        // Initialize bins
        for (int i = 0; i < solution.Max(); i++)
        {
            bins.Add(new List<double>());
        }

        // Assign items to bins
        for (int i = 0; i < solution.Count; i++)
        {
            bins[solution[i] - 1].Add(items[i]);
        }

        return bins;
    }
}