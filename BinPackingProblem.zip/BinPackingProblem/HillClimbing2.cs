public class RandomMutationHillClimbing2
{
    private List<double> items; 
    private double binCapacity; 
    private Random random; 

    public RandomMutationHillClimbing2(List<double> items, double binCapacity)
    {
        if (items == null || items.Count == 0)
            throw new ArgumentException("Item list cannot be null or empty.");
        if (binCapacity <= 0)
            throw new ArgumentException("Bin capacity must be greater than zero.");

        this.items = items;
        this.binCapacity = binCapacity;
        random = new Random();
    }

    public List<int> GenerateRandomInitialSolution()
    {
        var binAssignments = new List<int>(); 
        var bins = new List<List<double>>();  

        foreach (var item in items)
        {
            List<int> validBins = new List<int>();

            for (int i = 0; i < bins.Count; i++)
            {
                if (bins[i].Sum() + item <= binCapacity)
                {
                    validBins.Add(i);
                }
            }

            validBins.Add(bins.Count);

            int selectedBinIndex = validBins[random.Next(validBins.Count)];

            if (selectedBinIndex == bins.Count)
            {
                bins.Add(new List<double> { item });
                binAssignments.Add(bins.Count); 
            }
            else
            {
                bins[selectedBinIndex].Add(item);
                binAssignments.Add(selectedBinIndex + 1); // Use 1-based index
            }
        }

        return binAssignments;
    }

   
    public double EvaluateFitnessRemainingSpace(List<int> solution, out List<double> remainingSpace, out List<int> binAssignments)
    {
        var bins = new List<List<double>>();
        remainingSpace = new List<double>();
        binAssignments = new List<int>();

        foreach (var item in items)
        {
            bool added = false;
            for (int i = 0; i < bins.Count; i++)
            {
                if (bins[i].Sum() + item <= binCapacity)
                {
                    bins[i].Add(item);
                    binAssignments.Add(i + 1);
                    added = true;
                    break; //Exit for the for loop do it doesnt continue checking all bins after an item has been added
                }
            }
            if (!added)
            {
                bins.Add(new List<double> { item });
                binAssignments.Add(bins.Count);
            }
        }

        foreach (var bin in bins)
        {
            remainingSpace.Add(binCapacity - bin.Sum()); //Returns the remaning space of the bin based on its set capacity in the main
        }

        return remainingSpace.Sum();
    }

    public List<int> SmallChange(List<int> solution)
    {
        var newSolution = new List<int>(solution);
        var bins = GetBins(newSolution);

        int itemIndex = random.Next(newSolution.Count);
        double itemWeight = items[itemIndex];
        int currentBinIndex = newSolution[itemIndex] - 1;

        int newBinIndex = random.Next(bins.Count + 1); 
        while (newBinIndex == currentBinIndex ||
               (newBinIndex < bins.Count && bins[newBinIndex].Sum() + itemWeight > binCapacity))
        {
            newBinIndex = random.Next(bins.Count + 1);
        }

        if (newBinIndex >= bins.Count)
        {
            bins.Add(new List<double> { itemWeight }); 
        }
        else
        {
            bins[newBinIndex].Add(itemWeight);
        }
        bins[currentBinIndex].Remove(itemWeight);

        for (int i = 0; i < items.Count; i++)
        {
            for (int j = 0; j < bins.Count; j++)
            {
                if (bins[j].Contains(items[i]))
                {
                    newSolution[i] = j + 1;
                    break;
                }
            }
        }

        return newSolution;
    }



    public void RunRMHC(int iterations)
    {
        if (iterations <= 0)
            throw new ArgumentException("Number of iterations must be greater than zero.");

        var bestSolution = GenerateRandomInitialSolution();
        List<double> remainingSpace;
        List<int> binAssignments;
        double bestFitness = EvaluateFitnessRemainingSpace(bestSolution, out remainingSpace, out binAssignments);

        Console.WriteLine("Initial Solution:");
        PrintSolution(binAssignments, remainingSpace);

        ReadWriteFile.writeSolutions(new List<List<int>> { bestSolution }, "C:\\Users\\lewis\\Downloads\\Coding\\2024\\BinPackingProblem\\solutions.csv");

        for (var i = 0; i < iterations; i++)
        {
            Console.WriteLine($"Iteration {i + 1}: Current Best Fitness (Total Remaining Space): {bestFitness:F2}");

            var newSolution = SmallChange(bestSolution);
            var newFitness = EvaluateFitnessRemainingSpace(newSolution, out remainingSpace, out binAssignments);

            PrintSolution(binAssignments, remainingSpace);
            Console.WriteLine($"New Fitness: {newFitness:F2}");

            if (newFitness < bestFitness)
            {
                bestSolution = newSolution;
                bestFitness = newFitness;
                Console.WriteLine("Accepted new solution.");
            }
            else
            {
                Console.WriteLine("Rejected new solution.");
            }
            Console.WriteLine();
        }

        Console.WriteLine("Final Solution:");
        Console.WriteLine($"Best Fitness (Total Remaining Space): {bestFitness:F2}");
        PrintSolution(binAssignments, remainingSpace);
    }

    private void PrintSolution(List<int> binAssignments, List<double> remainingSpace)
    {
        Console.WriteLine("Bin Assignments for Items:");
        Console.WriteLine(string.Join(", ", binAssignments));
        Console.WriteLine("\nRemaining Space in Each Bin:");
        for (int i = 0; i < remainingSpace.Count; i++)
        {
            Console.WriteLine($"Bin {i + 1} -> Remaining Space: {remainingSpace[i]:F2}");
        }
    }


    private List<List<double>> GetBins(List<int> solution)
    {
        var bins = new List<List<double>>();

        for (int i = 0; i < solution.Max(); i++)
        {
            bins.Add(new List<double>());
        }

        for (int i = 0; i < solution.Count; i++)
        {
            bins[solution[i] - 1].Add(items[i]);
        }

        return bins;
    }
}


