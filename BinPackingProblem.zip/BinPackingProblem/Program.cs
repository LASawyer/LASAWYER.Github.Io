﻿class MainProgram
{
    static void Main(string[] args)
    {

        List<double> data = ReadWriteFile.readData("C:\\Users\\lewis\\Downloads\\Coding\\2024\\BinPackingProblem\\dataset.csv");
        const double binCapacity = 130.0;
        const int iterations = 300;

        //RandomMutationHillClimbing hc = new RandomMutationHillClimbing(data, binCapacity); //fitness function 1
        //hc.RunRMHC(iterations);

        RandomMutationHillClimbing2 hc = new RandomMutationHillClimbing2(data, binCapacity); //fitness function 2
        hc.RunRMHC(iterations);
    }
}