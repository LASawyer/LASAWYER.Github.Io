﻿using System;
using System.Collections;
using System.Data.SqlTypes;
using System.Globalization;
using System.Net.Http.Headers;
using System.Reflection;
using System.Runtime.CompilerServices;
namespace ProjectMM
{


    public class program
    {
        public static void Main()
        {
            SelectMenu(); // Calls the select menu code
            switch (Console.ReadLine()!.ToUpper())
            {
                case "A":
                    TrinaryConverter(); //Goes to trinary converter
                    break;
                case "B":
                    SchoolRoster(); // Goes to school roster
                    break;
                case "C":
                    isbnVerifier(); // goes to the isbn verfifer
                    break;
                case "Q":
                    Endprogram();
                    break;
            }
        }
        public static void SelectMenu() // All of this contains code for select menu
        {
            Console.WriteLine("Choose One of the following options");
            Console.WriteLine("-----------------------------------");
            Console.WriteLine("A) Trinary Converter");
            Console.WriteLine("B) School Roster");
            Console.WriteLine("C) ISBN Verifier");
            Console.WriteLine("Q) End the program");
        }

        public static int TrinaryConverter() 
        {
            string TrinaryValue;
            int value = 0;
            Console.WriteLine("Please enter a trinary number ");
            TrinaryValue = Console.ReadLine(); // makes whatever the value entered the trinary value
            for (int i = 0; i < TrinaryValue.Length; i++) // for the length of the string
            {
                int digit = int.Parse(TrinaryValue[i].ToString()); // parse each individual digit to make an integer
                int CPositionV = digit * (int)Math.Pow(3, TrinaryValue.Length - 1 - i); 
                value += CPositionV;
                Console.WriteLine(value); // This isn't nessesary for the completion however it also acts as a check for how much the total number is increasing to check for errors
            }
            return value;


        }
        public static void SchoolRoster() 
        {
            string name;
            string FormN;
            List<string> NamesinForm1 = new List<string>(); //Creating lists for forms up to 8
            List<string> NamesinForm2 = new List<string>();
            List<string> NamesinForm3 = new List<string>();
            List<string> NamesinForm4 = new List<string>();
            List<string> NamesinForm5 = new List<string>();
            List<string> NamesinForm6 = new List<string>();
            List<string> NamesinForm7 = new List<string>();
            List<string> NamesinForm8 = new List<string>();

            
            Console.WriteLine("Choose One of the following options"); //Similar to the previous menu but fitted for the school roster
            Console.WriteLine("-----------------------------------");
            Console.WriteLine("A) Add a new student to a form");
            Console.WriteLine("B) Check who's in a form");
            Console.WriteLine("C) Check all students in all forms");
            Console.WriteLine("D) Quit");

            switch (Console.ReadLine()!.ToUpper())
            {
                case "A":
                    do
                    {

                        Console.WriteLine("Enter a The first name of the new student. Type end to end loop. ");
                        name = Console.ReadLine()!;
                        if (name != "end") // if name is not equal to "end" Then ignore the next few lines and exit the loop
                         
                        {
                            Console.WriteLine("Enter the form of the student up to form 8"); 
                            switch (Console.ReadLine())
                            {
                                case "1":
                                    name += NamesinForm1;
                                    break;
                                case "2":
                                    name += NamesinForm2;
                                    break;
                                case "3":
                                    name += NamesinForm3;
                                    break;
                                case "4":
                                    name += NamesinForm4;
                                    break;
                                case "5":
                                    name += NamesinForm5;
                                    break;
                                case "6":
                                    name += NamesinForm6;
                                    break;
                                case "7":
                                    name += NamesinForm7;
                                    break;
                                case "8":
                                    name += NamesinForm8;
                                    break;
                                   
                            }
        
                        }

                    }
                    while (name != "end");
                    break;
                case "B":
                    Console.WriteLine("Which form would you like to check?");
                    FormN = Console.ReadLine()!;  

                    break;
                case "C":
                    Console.WriteLine(NamesinForm1);
                    Console.WriteLine("Is everyone in form 1 ");
                    Console.WriteLine(NamesinForm2);
                    Console.WriteLine("Is everyone in form 2");
                    Console.WriteLine(NamesinForm3);
                    Console.WriteLine("Is everyone in form 3");
                    Console.WriteLine(NamesinForm4);
                    Console.WriteLine("Is everyone in form 4");
                    Console.WriteLine(NamesinForm5);
                    Console.WriteLine("Is everyone in form 5");
                    Console.WriteLine(NamesinForm6);
                    Console.WriteLine("Is everyone in form 6");
                    Console.WriteLine(NamesinForm7);
                    Console.WriteLine("Is everyone in form 7");
                    Console.WriteLine(NamesinForm8);
                    Console.WriteLine("Is everyone in form 8");
                    break;
            }
        }

        public static void isbnVerifier()
        {
            string isbnValue;
            int totalsum = 0;
            Console.WriteLine("Please enter the Isbn-10 Value without any dashes presented as a string of numbers:");
            isbnValue = Console.ReadLine();
            if (isbnValue.Length != 10) //if the console length isn''t equal to 10
            {
                Console.WriteLine("This number isn' t the right amount of letter");
                return;
            }
            else
            for (int i = 0; i < 10; i++) // for the 10 digits of the code
            {
                    totalsum += (isbnValue[i] - '0') * (10 - i);

                    char LastDigit = isbnValue[9]; //It's meant to check the last digit to see if its x 
                    if (LastDigit == 'X')// and if it is then 
                    {
                        totalsum += 10; // add 10 to the total
                    }
                    //however it doesn't seem to like it when the isbnValue is 10 as it won't work and when it's 9 the (LastDigit =='X') code doesn't work properly

                    else
                    {
                        totalsum += 0;
                    }
                }

           

            if (totalsum % 11 == 0) // mod the total function by 11 and if it equals 0 its valid but if it doesn't its not then display that to the user
            {
                Console.WriteLine("The isbn value is valid");
            }
            else 
            {
                Console.WriteLine("The isbn value is not valid");
            }

        }

        static void Endprogram() 
        {
        return;
        }
    }

}
