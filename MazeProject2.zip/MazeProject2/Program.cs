﻿public class MazeSolver
{
    private int[,] maze;
    private bool[,] visited; // Added visited array
    private List<(int, int, string)> directions = new List<(int, int, string)> // first int represnts the y value and the second represents the x value
    {
        (-1, 0, "North"),
        (-1, 1, "Northeast"),
        (0, 1, "East"),
        (1, 1, "Southeast"),
        (1, 0, "South"),
        (1, -1, "Southwest"),
        (0, -1, "West"),
        (-1, -1, "Northwest")
    };

    public MazeSolver(int[,] maze)
    {
        this.maze = maze;
        this.visited = new bool[maze.GetLength(0), maze.GetLength(1)]; // Initialize visited array
    }

    public void FindPath((int row, int col) start, (int row, int col) end)
    {
        Console.WriteLine("Initial Maze:");
        PrintMaze();

        Stack<(int row, int col)> path = new Stack<(int, int)>();
        path.Push(start);
        visited[start.row, start.col] = true; // Mark start position as visited

        if (!DepthFirstSearch(path, end, 1))
        {
            Console.WriteLine("No path found to the exit.");
        }
    }

    private bool DepthFirstSearch(Stack<(int row, int col)> path, (int row, int col) end, int step)
    {
        var current = path.Peek();

        // Check if we've reached the end
        if (current == end)
        {
            Console.WriteLine("\nThe rat found a path to the exit!");
            PrintPath(path);
            return true;
        }

        foreach (var (dRow, dCol, direction) in directions)
        {
            var next = (row: current.row + dRow, col: current.col + dCol);

            // Check if next position is within bounds and not visited
            if (InBounds(next) && maze[next.row, next.col] == 0 && !visited[next.row, next.col])
            {
                visited[next.row, next.col] = true; // Mark as visited in visited array
                path.Push(next);
                Console.WriteLine($"Step {step++}: Moved {direction} to ({next.row}, {next.col})");
                PrintMaze(); // Prints the maze after each move to show path taken

                if (DepthFirstSearch(path, end, step))
                {
                    return true;
                }

                // Backtrack if no path forward
                path.Pop();
                visited[next.row, next.col] = false; // Unmark as visited
            }
        }

        return false; // No valid path from this position
    }

    private bool InBounds((int row, int col) position)
    {
        return position.row >= 0 && position.row < maze.GetLength(0) &&
               position.col >= 0 && position.col < maze.GetLength(1);
    }

    private void PrintPath(Stack<(int row, int col)> path)
    {
        var pathArray = path.ToArray();
        Array.Reverse(pathArray);
        Console.WriteLine("Path to the exit:");
        foreach (var (row, col) in pathArray)
        {
            Console.WriteLine($"({row}, {col})");
        }
    }

    private void PrintMaze()
    {
        for (int i = 0; i < maze.GetLength(0); i++)
        {
            for (int j = 0; j < maze.GetLength(1); j++)
            {
                if (maze[i, j] == 1) Console.Write("# ");        // Wall
                else if (visited[i, j]) Console.Write(". ");    // Visited path
                else Console.Write("  ");                       // Open path
            }
            Console.WriteLine();
        }
    }
}

public class MazeProgram
{
    public static void Main()
    {
        int[,] maze = {
          { 0, 0, 1, 1, 1, 1, 1},
          { 1, 0, 1, 1, 1, 1, 1},
          { 1, 1, 0, 0, 0, 0, 0},
          { 1, 1, 1, 1, 1, 1, 1},
          { 1, 1, 1, 1, 1, 1, 1}
        };

        var solver = new MazeSolver(maze);
        solver.FindPath((0, 0), (2, 6)); // Starting point (0, 0) to ending point (2, 6)
    }
}
/*{ 0, 0, 1, 1, 1, 1, 1},
  { 1, 0, 1, 1, 1, 1, 1},
  { 1, 1, 0, 0, 0, 0, 0},
  { 1, 1, 1, 1, 1, 1, 1},
  { 1, 1, 1, 1, 1, 1, 1}

/*{ 0, 0, 1},
{ 1, 0, 1},
{ 1, 1, 1}*/

/*{ 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
          { 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1},
          { 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1},
          { 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1},
          { 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1},
          { 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1},
          { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0}
*/